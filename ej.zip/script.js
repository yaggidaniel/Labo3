class Persona {
  constructor(id, nombre, apellido, edad) {
    if (typeof id !== 'number' || !!id === false) {
      throw new Error('El ID debe ser un número positivo.');
    }
    if (typeof nombre !== 'string' || !!nombre === false) {
      throw new Error('El nombre no puede estar vacío.');
    }
    if (typeof apellido !== 'string' || !!apellido === false) {
      throw new Error('El apellido no puede estar vacío.');
    }
    if (typeof edad !== 'number' || edad <= 0) {
      throw new Error('La edad debe ser un número positivo.');
    }

    this.id = id;
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
  }

  toString() {
    return `ID: ${this.id}, Nombre: ${this.nombre}, Apellido: ${this.apellido}, Edad: ${this.edad}`;
  }

  toJson() {
    return JSON.stringify(this);
  }
}

class Empleado extends Persona {
  constructor(id, nombre, apellido, edad, sueldo, ventas) {
    super(id, nombre, apellido, edad);

    if (typeof sueldo !== 'number' || sueldo <= 0) {
      throw new Error('El sueldo debe ser un número mayor a cero.');
    }

    if (typeof ventas !== 'number' || ventas <= 0) {
      throw new Error('Las ventas deben ser un número mayor a cero.');
    }

    this.sueldo = sueldo;
    this.ventas = ventas;
  }

  toString() {
    return `${super.toString()}, Sueldo: ${this.sueldo}, Ventas: ${this.ventas}`;
  }

  toJson() {
    return JSON.stringify(this);
  }
}

class Cliente extends Persona {
  constructor(id, nombre, apellido, edad, compras, telefono) {
    super(id, nombre, apellido, edad);

    if (typeof compras !== 'number' || compras <= 0) {
      throw new Error('Las compras deben ser un número mayor a cero.');
    }

    if (typeof telefono !== 'string' || telefono === '') {
      throw new Error('El teléfono no puede estar vacío.');
    }

    this.compras = compras;
    this.telefono = telefono;
  }

  toString() {
    return `${super.toString()}, Compras: ${this.compras}, Teléfono: ${this.telefono}`;
  }

  toJson() {
    return JSON.stringify(this);
  }
}

const empleados = [];
const clientes = [];

const data = [
  {
    "id": 1,
    "nombre": "Marcelo",
    "apellido": "Luque",
    "edad": 45,
    "ventas": 15000,
    "sueldo": 2000
  },
  {
    "id": 2,
    "nombre": "Ramiro",
    "apellido": "Escobar",
    "edad": 35,
    "ventas": 6000,
    "sueldo": 1000
  },
  {
    "id": 3,
    "nombre": "Facundo",
    "apellido": "Cairo",
    "edad": 30,
    "ventas": 500,
    "sueldo": 15000
  },
  {
    "id": 4,
    "nombre": "Fernando",
    "apellido": "Nieto",
    "edad": 18,
    "compras": 8000,
    "telefono": "152111131"
  },
  {
    "id": 5,
    "nombre": "Manuel",
    "apellido": "Loza",
    "edad": 20,
    "compras": 50000,
    "telefono": "42040077"
  },
  {
    "id": 666,
    "nombre": "Nicolas",
    "apellido": "Serrano",
    "edad": 23,
    "compras": 7000,
    "telefono": "1813181563"
  }
];

data.forEach((item) => {
  if ("sueldo" in item) {
    const empleado = new Empleado(item.id, item.nombre, item.apellido, item.edad, item.sueldo, item.ventas);
    empleados.push(empleado);
  } else if ("compras" in item) {
    const cliente = new Cliente(item.id, item.nombre, item.apellido, item.edad, item.compras, item.telefono);
    clientes.push(cliente);
  }
});

let itemEditado = null;

const tablaData = document.getElementById('tablaData');
const filtro = document.getElementById('filtro');
const checks = document.getElementById('checks');
const cabecera = document.getElementById('cabecera');
const dataDiv = document.getElementsByClassName('data')[0];
const formCliente = document.getElementById('cliente');
const formEmp = document.getElementById('empleado');
const btnAgregar = document.getElementById('btnAgregar');

const formularioCliente = document.getElementById('formularioCliente');
const formularioEmpleados = document.getElementById('formularioEmpleados');
const bntAddClient = document.getElementById('bntAddClient');
const bntAddEmployee = document.getElementById('bntAddEmployee');
const cancelarEmp = document.getElementById('cancelarEmp');
const cancelarCli = document.getElementById('cancelarCli');

const showAdd = (tipo) => {
  if (tipo === 'empleados') {
    dataDiv.classList.add('hidden');
    formCliente.classList.add('hidden');
    formEmp.classList.remove('hidden');
  } else {
    dataDiv.classList.add('hidden');
    formEmp.classList.add('hidden');
    formCliente.classList.remove('hidden');
  }
}

const showData = () => {
  dataDiv.classList.remove('hidden');
  formCliente.classList.add('hidden');
  formEmp.classList.add('hidden');
}

btnAgregar.addEventListener('click', () => {
  showAdd(filtro.value);
})

cancelarEmp.addEventListener('click', () => {
  resetAfterForm(filtro.value);
})
cancelarCli.addEventListener('click', () => {
  resetAfterForm(filtro.value);
})

const setChecks = (tipo) => {
  if (tipo === 'empleados') {
    checks.innerHTML = `
    <label>Columnas a mostrar:</label>
        <input type="checkbox" id="chkId" checked> <label for="chkId">ID</label>
        <input type="checkbox" id="chkNombre" checked> <label for="chkNombre">Nombre</label>
        <input type="checkbox" id="chkApellido" checked> <label for="chkApellido">Apellido</label>
        <input type="checkbox" id="chkEdad" checked> <label for="chkEdad">Edad</label>
        <input type="checkbox" id="chkSueldo" checked> <label for="chkSueldo">Sueldo</label>
        <input type="checkbox" id="chkVentas" checked> <label for="chkVentas">Ventas</label>
  `;
  } else {
    checks.innerHTML = `
    <label>Columnas a mostrar:</label>
    <input type="checkbox" id="chkId" checked> <label for="chkId">ID</label>
    <input type="checkbox" id="chkNombre" checked> <label for="chkNombre">Nombre</label>
    <input type="checkbox" id="chkApellido" checked> <label for="chkApellido">Apellido</label>
    <input type="checkbox" id="chkEdad" checked> <label for="chkEdad">Edad</label>
    <input type="checkbox" id="chkCompras" checked> <label for="chkCompras">Compras</label>
    <input type="checkbox" id="chkTelefono" checked> <label for="chkTelefono">Teléfono</label>
    `;
  }
  const cbox = document.querySelectorAll('input[type=checkbox]');
  for (const element of cbox) {
    element.addEventListener("click", (e) => {
      resetTable();
      armarCabecera(filtro?.value);
      agregarFilas(filtro?.value);
    });
}
}

const armarCabecera = (tipo) => {
  const chkId = document.getElementById('chkId').checked;
  const chkNombre = document.getElementById('chkNombre').checked;
  const chkApellido = document.getElementById('chkApellido').checked;
  const chkEdad = document.getElementById('chkEdad').checked;
  const chkSueldo = document?.getElementById('chkSueldo')?.checked;
  const chkVentas = document?.getElementById('chkVentas')?.checked;
  const chkCompras = document?.getElementById('chkCompras')?.checked;
  const chkTelefono = document?.getElementById('chkTelefono')?.checked;

  const crearCabecera = (titulo) => {
    const th = document.createElement('th');
    th.innerHTML = titulo;
    return th;
  }
  chkId ? cabecera.append(crearCabecera('ID')) : null;
  chkNombre ? cabecera.append(crearCabecera('Nombre')) : null;
  chkApellido ? cabecera.append(crearCabecera('Apellido')) : null;
  chkEdad ? cabecera.append(crearCabecera('Edad')) : null;
  
  if (tipo === 'empleados') {
    chkSueldo ? cabecera.append(crearCabecera('Saldo')) : null;
    chkVentas ? cabecera.append(crearCabecera('Ventas')) : null;
  } else {
    chkCompras ? cabecera.append(crearCabecera('Compras')) : null;
    chkTelefono ? cabecera.append(crearCabecera('Telefono')) : null;
  }
}

const agregarFilas = (tipo) => {
  const chkId = document.getElementById('chkId').checked;
  const chkNombre = document.getElementById('chkNombre').checked;
  const chkApellido = document.getElementById('chkApellido').checked;
  const chkEdad = document.getElementById('chkEdad').checked;
  const chkSueldo = document?.getElementById('chkSueldo')?.checked;
  const chkVentas = document?.getElementById('chkVentas')?.checked;
  const chkCompras = document?.getElementById('chkCompras')?.checked;
  const chkTelefono = document?.getElementById('chkTelefono')?.checked;

  const source = tipo === 'empleados' ? empleados : clientes;

  source.forEach(item => {
      const fila = document.createElement('tr');
      let data = '';
      if (chkId) data += `<td>${item.id}</td>`;
      if (chkNombre) data += `<td>${item.nombre}</td>`;
      if (chkApellido) data += `<td>${item.apellido}</td>`;
      if (chkEdad) data += `<td>${item.edad}</td>`;
      if (chkSueldo && tipo === 'empleados') data += `<td>${item.sueldo}</td>`;
      if (chkVentas && tipo === 'empleados') data += `<td>${item.ventas}</td>`;
      if (chkCompras && tipo === 'clientes') data += `<td>${item.compras}</td>`;
      if (chkTelefono && tipo === 'clientes') data += `<td>${item.telefono}</td>`;
      fila.innerHTML = data;
      fila.addEventListener('click', () => {
        document.getElementById('id').value = item.id;
        itemEditado = item;
        showAdd(tipo);
        if (tipo === 'empleados') {
          document.getElementById('nombreEmpleado').value = item.nombre;
          document.getElementById('apellidoEmpleado').value = item.apellido;
          document.getElementById('edadEmpleado').value = item.edad;
          document.getElementById('sueldoEmpleado').value = item.sueldo;
          document.getElementById('ventasEmpleado').value = item.ventas;
        } else {
          document.getElementById('nombreCliente').value = item.nombre;
          document.getElementById('apellidoCliente').value = item.apellido;
          document.getElementById('edadCliente').value = item.edad;
          document.getElementById('comprasCliente').value = item.compras;
          document.getElementById('telefonoCliente').value = item.telefono;
        }
    });
      tablaData.appendChild(fila);
  });
}

setChecks('empleados');
armarCabecera('empleados');
agregarFilas('empleados');

const resetTable = () => {
  cabecera.innerHTML = '';
  tablaData.innerHTML = '';
}

const resetAfterForm = (valor) => {
  showData();
  document.getElementById('errorMensaje').textContent = "";
  filtro.value = valor;
  resetTable();
  setChecks(valor);
  armarCabecera(valor);
  agregarFilas(valor);
  itemEditado = null;
}

filtro.addEventListener('change', (e) => {
  const valor = e.target.value;
  resetTable();
  setChecks(valor);
  armarCabecera(valor);
  agregarFilas(valor);
});

bntAddClient?.addEventListener('click', (e) => {
    e.preventDefault();
    const nombre = document.getElementById('nombreCliente').value;
    const apellido = document.getElementById('apellidoCliente').value;
    const edad = parseInt(document.getElementById('edadCliente').value);
    const compras = parseFloat(document.getElementById('comprasCliente').value);
    const telefono = document.getElementById('telefonoCliente').value;

    if (itemEditado) {
      itemEditado.nombre = nombre;
      itemEditado.apellido = apellido;
      itemEditado.edad = edad;
      itemEditado.compras = compras;
      itemEditado.telefono = telefono;
    } else {
      try {
        let nuevoId = 1;
        while (clientes.some(cliente => cliente.id === nuevoId)) {
            nuevoId++;
        }
        const nuevoCliente = new Cliente(nuevoId, nombre, apellido, edad, compras, telefono);
        clientes.push(nuevoCliente);
    } catch (error) {
        document.getElementById('errorMensaje').textContent = error.message;
    }
  }
  formularioCliente.reset();
  resetAfterForm('clientes');
});

bntAddEmployee?.addEventListener('click', (e) => {
    e.preventDefault();
    const nombre = document.getElementById('nombreEmpleado').value;
    const apellido = document.getElementById('apellidoEmpleado').value;
    const edad = parseInt(document.getElementById('edadEmpleado').value);
    const sueldo = parseFloat(document.getElementById('sueldoEmpleado').value);
    const ventas = parseFloat(document.getElementById('ventasEmpleado').value);
    if (itemEditado) {
      itemEditado.nombre = nombre;
      itemEditado.apellido = apellido;
      itemEditado.edad = edad;
      itemEditado.sueldo = sueldo;
      itemEditado.ventas = ventas;
    } else {
        try {
          let nuevoId = 1;
          while (empleados.some(cliente => cliente.id === nuevoId)) {
              nuevoId++;
          }
          const nuevoEmpleado = new Empleado(nuevoId, nombre, apellido, edad, sueldo, ventas);
          empleados.push(nuevoEmpleado);
      } catch (error) {
          document.getElementById('errorMensaje').textContent = error.message;
      }
    }
    formularioEmpleados.reset();
    resetAfterForm('empleados');
});
